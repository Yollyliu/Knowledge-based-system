package codalog;

import java.util.*;
import parser.*;
import util.*;
import evaluater.*;

public class Codalog
{
	public static ArrayList<Fact> facts=new ArrayList<>();
	public static ArrayList<Rule> rules=new ArrayList<>();
	public static ArrayList<String> inputSentences=new ArrayList<>();
	public static HashMap<String,PredicateLog> predicates=new HashMap<String,PredicateLog>();
	public static String filePath = "./datalogProgram/";
	public static String fileName="P6.cdl";
	public static int fileOption=2;//0 for file;1 for console;2 for both 
	public static boolean seminaive=false;
	public static boolean trace=false;
	public static boolean fileprint=true;
	public static Literal userQuery=null;
	
	public static void main(String[] args)
	{
		Init.initialize();	
		Parser.fileReader();
		if(Parser.parse())
		{
//			for(Rule rule:rules)
//				Print.printRule(rule);
//			for(Fact fact:facts)
//				Print.printFact(fact);
			long starTime=System.currentTimeMillis();
			Evaluater.evaluation();
			long endTime=System.currentTimeMillis();
			long ttime=endTime-starTime;
			System.out.println(ttime+" ms");
			//System.out.println(Evaluater.allcount);
			
			String userquery="";
			Scanner sc=new Scanner(System.in);
			sc.useDelimiter("\n");
			
			System.out.println("Type in your query:(exit with 0)");
			while (sc.hasNext())
			{
				userquery=sc.next().trim();
				if(userquery.equals("0"))
					break;
				if(Parser.checkQuery(userquery))			
					if(Evaluater.query())
					{
						if(Evaluater.groundQuery)
						{
							System.out.println("true");
							Evaluater.groundQuery=false;
						}
					}
					else 
					{
						System.out.println("false");
					}				
				else				
					System.out.println("Wrong user-query.");
				System.out.println("Type in your query:(exit with 0)");				
			}				
		}
	}
}
