package util;

public class PredicateLog
{
	public String ie="";
	public int arity=0;
	public boolean built_in=false;
	public PredicateLog()
	{
		
	}
	public PredicateLog(String iee,int ari,boolean bi)
	{
		this.ie=iee;
		this.arity=ari;
		this.built_in=bi;
	}
}
