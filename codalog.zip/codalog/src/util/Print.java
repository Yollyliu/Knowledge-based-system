package util;

public class Print
{
	public static void printRule(Rule rule)
	{
		System.out.print(rule.head.predicate);
		System.out.print("(");
		for(int i=0;i<rule.head.varia.length-1;i++)
			System.out.print(rule.head.varia[i].name+",");
		System.out.print(rule.head.varia[rule.head.varia.length-1].name+"):-");
		for(int i=0;i<rule.body.size()-1;i++)
		{
			Literal currentLiteral=rule.body.get(i);
			System.out.print(currentLiteral.predicate+"(");
			for(int j=0;j<currentLiteral.varia.length-1;j++)
				System.out.print(currentLiteral.varia[j].name+",");
			System.out.print(currentLiteral.varia[currentLiteral.varia.length-1].name+")");
			System.out.print(",");
		}
		System.out.print(rule.body.get(rule.body.size()-1).predicate+"(");
		for(int i=0;i<rule.body.get(rule.body.size()-1).varia.length-1;i++)
			System.out.print(rule.body.get(rule.body.size()-1).varia[i].name+",");
		System.out.print(rule.body.get(rule.body.size()-1).varia[rule.body.get(rule.body.size()-1).varia.length-1].name+").");
		System.out.println();
	}
	
	public static void printFact(Fact fact)
	{
		System.out.print(fact.predicate+"(");
		for(int i=0;i<fact.constant.length-1;i++)
			System.out.print(fact.constant[i].name+",");
		System.out.print(fact.constant[fact.constant.length-1].name+").");
		System.out.println();
	}
}
