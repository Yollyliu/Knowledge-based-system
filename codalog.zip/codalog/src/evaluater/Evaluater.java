package evaluater;

import java.util.*;
import codalog.*;
import parser.*;
import util.*;

public class Evaluater
{
	public static int allcount = 0;
	public static HashMap<String, ArrayList<Fact>> edb = new HashMap<String, ArrayList<Fact>>();
	public static HashMap<String, ArrayList<Fact>> idb = new HashMap<String, ArrayList<Fact>>();

	public static HashMap<String, ArrayList<Fact>> newidb;
	public static HashMap<String, ArrayList<Fact>> lastIdb;
	public static HashMap<String, ArrayList<Fact>> evaluEdb;
	public static ArrayList<Rule> evaluRules;
	public static boolean groundQuery=false;

	public static int iteration = 0;

	public static void evaluation()
	{
		for (Fact fact : Codalog.facts)
		{
			ArrayList<Fact> al = null;
			al = edb.get(fact.predicate);
			if (al == null)
			{
				al = new ArrayList<Fact>();
				al.add(fact);
				edb.put(fact.predicate, al);
			} else
			{
				al.add(fact);
				edb.put(fact.predicate, al);
			}
		}

		evaluRules = new ArrayList<Rule>();
		for (Rule rule : Codalog.rules)
			evaluRules.add(rule);

		boolean continu = true;

		while (continu)
		{
			newidb = new HashMap<String, ArrayList<Fact>>();
			if (Codalog.seminaive)
			{
				if (iteration != 0)
				{
					for (int r = 0; r < evaluRules.size(); r++)
					{
						Rule rul = evaluRules.get(r);
						boolean showup = false;
						for (int l = 0; l < rul.body.size(); l++)
						{
							Literal lite = rul.body.get(l);
							for (int r2 = 0; r2 < evaluRules.size(); r2++)
							{
								Rule rul2 = evaluRules.get(r2);
								if (lite.predicate.equals(rul2.head.predicate))
								{
									showup = true;
								}
							}
						}
						if (showup == false)
						{
							traceOn("delete��" + rul.head.predicate + "\n");
							evaluRules.remove(r);
							r--;
						}
					}
					traceOn("After deleting rules, we have rules��" + evaluRules.size() + "\n");
				}
			}

			for (int r = 0; r < evaluRules.size(); r++)
			{
				Rule currentRule = evaluRules.get(r);
				HashMap<String, String> substitution = new HashMap<String, String>();
				if (Codalog.seminaive)
					semimatch(0, substitution, currentRule, false);
				else
					naivematch(0, substitution, currentRule);

			}

			int iterationCount = 0;

			if (Codalog.seminaive)
			{
				unlabelidb();
			}
			iterationCount = labelnewidb(Codalog.seminaive);

			// System.out.println(iterationCount);
			traceOn("new idb size:" + newidb.size() + "\n");

			if (iterationCount == 0)
			{
				continu = false;
			}
			allcount += iterationCount;

			combine();

			traceOn("idb size:" + idb.size() + "\n");

			iteration++;
		}
	}

	public static boolean query()
	{
		boolean ans = false;
		Literal currentSubgoal = Codalog.userQuery;

		String[] instance = new String[currentSubgoal.varia.length];
		boolean[] matched = new boolean[currentSubgoal.varia.length];

		for (int v = 0; v < currentSubgoal.varia.length; v++)
		{
			if (!currentSubgoal.varia[v].isVariable)
			{
				instance[v] = currentSubgoal.varia[v].name;
				matched[v] = true;
			}
		}

		boolean allmatched=true;
		for(int v=0;v<currentSubgoal.varia.length;v++)
			if(!matched[v])
				allmatched=false;
		if(allmatched)
			groundQuery=true;
		
		PredicateLog pLog=null;
		pLog=Codalog.predicates.get(currentSubgoal.predicate);
		
		if (pLog!=null&&pLog.ie.equals("i"))// idbν��
		{
			ArrayList<Fact> localIdb = null;
			localIdb = idb.get(currentSubgoal.predicate);
			if (localIdb != null)
			{
				for (int i = 0; i < localIdb.size(); i++)
				{
					boolean canMatch = true;
					for (int v = 0; v < currentSubgoal.varia.length; v++)
					{
						if (matched[v] == true && !localIdb.get(i).constant[v].name.equals(instance[v]))
						{
							canMatch = false;
							break;
						}
					}
					if (canMatch == true)
					{						
						if(!groundQuery)
						{
							for(int v=0;v<currentSubgoal.varia.length;v++)
								if(currentSubgoal.varia[v].isVariable)
									System.out.print(currentSubgoal.varia[v].name+"="+localIdb.get(i).constant[v].name+" ");
							System.out.println();
						}						
						ans=true;
					}

				}
			}
		} 
		else// edb weici
		{
			if(pLog!=null)
			{
				ArrayList<Fact> localEdb = null;
				localEdb = edb.get(currentSubgoal.predicate);
				if (localEdb != null)
				{
					for (int e = 0; e < localEdb.size(); e++)
					{
						boolean canMatch = true;
						for (int v = 0; v < currentSubgoal.varia.length; v++)
						{
							if (matched[v] == true && !localEdb.get(e).constant[v].name.equals(instance[v]))
							{
								canMatch = false;
								break;
							}
						}
						if (canMatch == true)
						{
							if(!groundQuery)
							{
								for(int v=0;v<currentSubgoal.varia.length;v++)
									if(currentSubgoal.varia[v].isVariable)
										System.out.print(currentSubgoal.varia[v].name+"="+localEdb.get(e).constant[v].name+" ");
								System.out.println();
							}
							ans=true;
						}
					}
				}
			}
		}
		return ans;
	}

	public static void unlabelidb()
	{
		for (String str : idb.keySet())
		{
			ArrayList<Fact> aList = null;
			aList = idb.get(str);
			if (aList != null)
				for (Fact f : aList)
				{
					f.lastGenerated = false;
				}
		}
	}

	public static int labelnewidb(boolean need)
	{
		int num = 0;
		for (String str : newidb.keySet())
		{
			ArrayList<Fact> aList = null;
			aList = newidb.get(str);
			if (aList != null)
				for (Fact f : aList)
				{
					if (need)
						f.lastGenerated = true;
					num++;
				}
		}
		return num;
	}

	public static void combine()
	{
		for (String str : newidb.keySet())
		{
			ArrayList<Fact> bList = null;
			bList = newidb.get(str);
			if (bList != null)
			{
				ArrayList<Fact> aList = null;
				aList = idb.get(str);
				if (aList == null)
				{
					idb.put(str, bList);
				} else
				{
					for (Fact f : bList)
						aList.add(f);
				}
			}
		}
	}

	public static void semimatch(int depth, HashMap<String, String> parentSubstitution, Rule matchRule,
			boolean usedNewFacts)
	{
		traceOn("Subgoal " + depth + ":");
		HashMap<String, String> substitution = new HashMap<String, String>();
		for (String str : parentSubstitution.keySet())
		{
			substitution.put(str, parentSubstitution.get(str));
		}
		Literal currentSubgoal = matchRule.body.get(depth);
		String[] instance = new String[currentSubgoal.varia.length];
		boolean[] matched = new boolean[currentSubgoal.varia.length];
		for (int v = 0; v < currentSubgoal.varia.length; v++)
		{
			if (!currentSubgoal.varia[v].isVariable)
			{
				instance[v] = currentSubgoal.varia[v].name;
				matched[v] = true;
			}
		}
		for (int v = 0; v < currentSubgoal.varia.length; v++)
		{
			if (!matched[v])
			{
				String substi = null;
				substi = substitution.get(currentSubgoal.varia[v].name);
				if (substi != null)
				{
					matched[v] = true;
					traceOn(v + " matched true: " + substi + ";" + "\n");
				}
				instance[v] = substi;
			}
		}

		if (Codalog.predicates.get(currentSubgoal.predicate).ie.equals("i"))// idbν��
		{
			// if (lastRelaPredi.contains(currentSubgoal.predicate))
			// {
			// System.out.println("lastP contation:"+currentSubgoal.predicate);
			ArrayList<Fact> localIdb = null;
			localIdb = idb.get(currentSubgoal.predicate);
			if (localIdb != null)
			{
				for (int i = 0; i < localIdb.size(); i++)
				{
					traceOn("matching��" + i + localIdb.get(i).predicate + "\n");
					boolean canMatch = true;
					for (int v = 0; v < currentSubgoal.varia.length; v++)
					{
						if (matched[v] == true && !localIdb.get(i).constant[v].name.equals(instance[v]))
						{
							traceOn("at " + v + " disagreement matching" + "\n");
							canMatch = false;
							break;
						}
					}
					if (canMatch == true)
					{
						for (int v = 0; v < currentSubgoal.varia.length; v++)
						{
							if (matched[v] == false)
							{
								traceOn("add to substitution��" + currentSubgoal.varia[v] + "--"
										+ localIdb.get(i).constant[v].name);
								substitution.put(currentSubgoal.varia[v].name, localIdb.get(i).constant[v].name);
							}
						}

						boolean next = false;
						if (usedNewFacts)
							next = true;
						else
							next = localIdb.get(i).lastGenerated;

						if (depth < matchRule.body.size() - 1)
							semimatch(depth + 1, substitution, matchRule, next);
						else
						{
							if (next)
							{
								Term[] consta = new Term[matchRule.head.varia.length];
								for (int v = 0; v < matchRule.head.varia.length; v++)
								{
									if (matchRule.head.varia[v].isVariable)
										consta[v] = new Term(substitution.get(matchRule.head.varia[v].name), false);
									else
										consta[v] = matchRule.head.varia[v];
								}
								Fact newfact = new Fact(-1, matchRule.head.predicate, consta);

								boolean canInsert = true;
								ArrayList<Fact> al = null;
								al = idb.get(newfact.predicate);
								if (al != null)
								{
									for (int f = 0; f < al.size(); f++)
									{
										Fact currentFact = al.get(f);
										boolean allequal = true;
										for (int j = 0; j < currentFact.constant.length; j++)
										{
											if (!currentFact.constant[j].name.equals(newfact.constant[j].name))
											{
												allequal = false;
											}
										}
										if (allequal == true)
										{
											canInsert = false;
										}
									}
								}
								if (canInsert == true)
								{
									Print.printFact(newfact);
									ArrayList<Fact> nal = null;
									nal = newidb.get(newfact.predicate);
									if (nal == null)
									{
										nal = new ArrayList<Fact>();
									}
									nal.add(newfact);
									newidb.put(newfact.predicate, nal);
								}
							}
						}
						for (int v = 0; v < currentSubgoal.varia.length; v++)
						{
							if (matched[v] == false)
							{
								traceOn("delete from substitution��" + currentSubgoal.varia[v] + "--"
										+ localIdb.get(i).constant[v].name + "\n");
								substitution.remove(currentSubgoal.varia[v].name);
							}
						}
					}

				}
			}
		} else// edb weici
		{
			if (currentSubgoal.predicate.charAt(0) == 33
					|| (currentSubgoal.predicate.charAt(0) >= 60 && currentSubgoal.predicate.charAt(0) <= 62))// built-in
			{
				if (matched[0] && matched[1])
				{
					if ((currentSubgoal.predicate.equals("=") && instance[0].equals(instance[1]))
							|| (currentSubgoal.predicate.equals("!=") && !instance[0].equals(instance[1]))
							|| (currentSubgoal.predicate.equals(">") && stringCompare(instance[0], instance[1]) == 1)
							|| (currentSubgoal.predicate.equals("<") && stringCompare(instance[0], instance[1]) == -1)
							|| (currentSubgoal.predicate.equals(">=")
									&& (instance[0].equals(instance[1]) || stringCompare(instance[0], instance[1]) == 1
											|| stringCompare(instance[0], instance[1]) == 0))
							|| (currentSubgoal.predicate.equals("<=")
									&& (instance[0].equals(instance[1]) || stringCompare(instance[0], instance[1]) == -1
											|| stringCompare(instance[0], instance[1]) == 0)))
					{
						if (depth < matchRule.body.size() - 1)
							semimatch(depth + 1, substitution, matchRule, usedNewFacts);
						else
						{
							if ((!usedNewFacts && iteration == 0) || usedNewFacts)
							{
								Term[] consta = new Term[matchRule.head.varia.length];
								for (int i = 0; i < matchRule.head.varia.length; i++)
								{
									if (matchRule.head.varia[i].isVariable)
										consta[i] = new Term(substitution.get(matchRule.head.varia[i].name), false);
									else
										consta[i] = matchRule.head.varia[i];
								}
								Fact newfact = new Fact(-1, matchRule.head.predicate, consta);

								boolean canInsert = true;
								ArrayList<Fact> al = null;
								al = idb.get(newfact.predicate);
								if (al != null)
								{
									for (int i = 0; i < al.size(); i++)
									{
										Fact currentFact = al.get(i);
										boolean allequal = true;
										for (int j = 0; j < currentFact.constant.length; j++)
										{
											if (!currentFact.constant[j].name.equals(newfact.constant[j].name))
											{
												allequal = false;
											}
										}
										if (allequal == true)
										{
											canInsert = false;
										}
									}
								}
								if (canInsert == true)
								{
									Print.printFact(newfact);
									ArrayList<Fact> nal = null;
									nal = newidb.get(newfact.predicate);
									if (nal == null)
									{
										nal = new ArrayList<Fact>();
									}
									nal.add(newfact);
									newidb.put(newfact.predicate, nal);
								}
							}
						}
					}
				}
			} else// edb weici
			{
				ArrayList<Fact> localEdb = null;
				localEdb = edb.get(currentSubgoal.predicate);
				if (localEdb != null)
				{
					for (int e = 0; e < localEdb.size(); e++)
					{
						traceOn("matching��" + e + localEdb.get(e).predicate + "\n");
						boolean canMatch = true;
						for (int v = 0; v < currentSubgoal.varia.length; v++)
						{
							if (matched[v] == true && !localEdb.get(e).constant[v].name.equals(instance[v]))
							{
								traceOn("at " + v + " disagreement matching" + "\n");
								canMatch = false;
								break;
							}
						}
						if (canMatch == true)
						{
							for (int v = 0; v < currentSubgoal.varia.length; v++)
							{
								if (matched[v] == false)
								{
									traceOn("add to substitution��" + currentSubgoal.varia[v] + "--"
											+ localEdb.get(e).constant[v].name);
									substitution.put(currentSubgoal.varia[v].name, localEdb.get(e).constant[v].name);
								}
							}
							if (depth < matchRule.body.size() - 1)
								semimatch(depth + 1, substitution, matchRule, usedNewFacts);
							else
							{
								if ((!usedNewFacts && iteration == 0) || usedNewFacts)
								{
									Term[] consta = new Term[matchRule.head.varia.length];
									for (int i = 0; i < matchRule.head.varia.length; i++)
									{
										if (matchRule.head.varia[i].isVariable)
											consta[i] = new Term(substitution.get(matchRule.head.varia[i].name), false);
										else
											consta[i] = matchRule.head.varia[i];
									}
									Fact newfact = new Fact(-1, matchRule.head.predicate, consta);

									boolean canInsert = true;
									ArrayList<Fact> al = null;
									al = idb.get(newfact.predicate);
									if (al != null)
									{
										for (int i = 0; i < al.size(); i++)
										{
											Fact currentFact = al.get(i);
											boolean allequal = true;
											for (int j = 0; j < currentFact.constant.length; j++)
											{
												if (!currentFact.constant[j].name.equals(newfact.constant[j].name))
												{
													allequal = false;
												}
											}
											if (allequal == true)
											{
												canInsert = false;
											}
										}
									}
									if (canInsert == true)
									{
										Print.printFact(newfact);
										ArrayList<Fact> nal = null;
										nal = newidb.get(newfact.predicate);
										if (nal == null)
										{
											nal = new ArrayList<Fact>();
										}
										nal.add(newfact);
										newidb.put(newfact.predicate, nal);
									}
								}
							}
							for (int v = 0; v < currentSubgoal.varia.length; v++)
							{
								if (matched[v] == false)
								{
									traceOn("delete from substitution��" + currentSubgoal.varia[v] + "--"
											+ localEdb.get(e).constant[v].name + "\n");
									substitution.remove(currentSubgoal.varia[v].name);
								}
							}
						}

					}
				}
			}

		}
	}

	public static void naivematch(int depth, HashMap<String, String> parentSubstitution, Rule matchRule)
	{
		traceOn("Subgoal " + depth + ":");
		HashMap<String, String> substitution = new HashMap<String, String>();
		for (String str : parentSubstitution.keySet())
		{
			substitution.put(str, parentSubstitution.get(str));
		}
		Literal currentSubgoal = matchRule.body.get(depth);
		String[] instance = new String[currentSubgoal.varia.length];
		boolean[] matched = new boolean[currentSubgoal.varia.length];
		for (int v = 0; v < currentSubgoal.varia.length; v++)
		{
			if (!currentSubgoal.varia[v].isVariable)
			{
				instance[v] = currentSubgoal.varia[v].name;
				matched[v] = true;
			}
		}
		for (int v = 0; v < currentSubgoal.varia.length; v++)
		{
			if (!matched[v])
			{
				String substi = null;
				substi = substitution.get(currentSubgoal.varia[v].name);
				if (substi != null)
				{
					matched[v] = true;
					traceOn(v + " matched true: " + substi + ";" + "\n");
				}
				instance[v] = substi;
			}
		}

		if (Codalog.predicates.get(currentSubgoal.predicate).ie.equals("i"))// idbν��
		{
			ArrayList<Fact> localIdb = null;
			localIdb = idb.get(currentSubgoal.predicate);
			if (localIdb != null)
			{
				for (int i = 0; i < localIdb.size(); i++)
				{
					traceOn("matching��" + i + localIdb.get(i).predicate + "\n");
					boolean canMatch = true;
					for (int v = 0; v < currentSubgoal.varia.length; v++)
					{
						if (matched[v] == true && !localIdb.get(i).constant[v].name.equals(instance[v]))
						{
							traceOn("at " + v + " disagreement matching" + "\n");
							canMatch = false;
							break;
						}
					}
					if (canMatch == true)
					{
						for (int v = 0; v < currentSubgoal.varia.length; v++)
						{
							if (matched[v] == false)
							{
								traceOn("add to substitution��" + currentSubgoal.varia[v] + "--"
										+ localIdb.get(i).constant[v].name);
								substitution.put(currentSubgoal.varia[v].name, localIdb.get(i).constant[v].name);
							}
						}

						if (depth < matchRule.body.size() - 1)
							naivematch(depth + 1, substitution, matchRule);
						else
						{
							Term[] consta = new Term[matchRule.head.varia.length];
							for (int v = 0; v < matchRule.head.varia.length; v++)
							{
								if (matchRule.head.varia[v].isVariable)
									consta[v] = new Term(substitution.get(matchRule.head.varia[v].name), false);
								else
									consta[v] = matchRule.head.varia[v];
							}
							Fact newfact = new Fact(-1, matchRule.head.predicate, consta);

							boolean canInsert = true;
							ArrayList<Fact> al = null;
							al = idb.get(newfact.predicate);
							if (al != null)
							{
								for (int f = 0; f < al.size(); f++)
								{
									Fact currentFact = al.get(f);
									boolean allequal = true;
									for (int j = 0; j < currentFact.constant.length; j++)
									{
										if (!currentFact.constant[j].name.equals(newfact.constant[j].name))
										{
											allequal = false;
										}
									}
									if (allequal == true)
									{
										canInsert = false;
									}
								}
							}
							if (canInsert == true)
							{
								Print.printFact(newfact);
								ArrayList<Fact> nal = null;
								nal = newidb.get(newfact.predicate);
								if (nal == null)
								{
									nal = new ArrayList<Fact>();
								}
								nal.add(newfact);
								newidb.put(newfact.predicate, nal);
							}
						}
						for (int v = 0; v < currentSubgoal.varia.length; v++)
						{
							if (matched[v] == false)
							{
								traceOn("delete from substitution��" + currentSubgoal.varia[v] + "--"
										+ localIdb.get(i).constant[v].name + "\n");
								substitution.remove(currentSubgoal.varia[v].name);
							}
						}
					}

				}
			}
		} else// edb weici
		{
			if (currentSubgoal.predicate.charAt(0) == 33
					|| (currentSubgoal.predicate.charAt(0) >= 60 && currentSubgoal.predicate.charAt(0) <= 62))// built-in
			{
				if (matched[0] && matched[1])
				{
					if ((currentSubgoal.predicate.equals("=") && instance[0].equals(instance[1]))
							|| (currentSubgoal.predicate.equals("!=") && !instance[0].equals(instance[1]))
							|| (currentSubgoal.predicate.equals(">") && stringCompare(instance[0], instance[1]) == 1)
							|| (currentSubgoal.predicate.equals("<") && stringCompare(instance[0], instance[1]) == -1)
							|| (currentSubgoal.predicate.equals(">=")
									&& (instance[0].equals(instance[1]) || stringCompare(instance[0], instance[1]) == 1
											|| stringCompare(instance[0], instance[1]) == 0))
							|| (currentSubgoal.predicate.equals("<=")
									&& (instance[0].equals(instance[1]) || stringCompare(instance[0], instance[1]) == -1
											|| stringCompare(instance[0], instance[1]) == 0)))
					{
						if (depth < matchRule.body.size() - 1)
							naivematch(depth + 1, substitution, matchRule);
						else
						{
							Term[] consta = new Term[matchRule.head.varia.length];
							for (int i = 0; i < matchRule.head.varia.length; i++)
							{
								if (matchRule.head.varia[i].isVariable)
									consta[i] = new Term(substitution.get(matchRule.head.varia[i].name), false);
								else
									consta[i] = matchRule.head.varia[i];
							}
							Fact newfact = new Fact(-1, matchRule.head.predicate, consta);

							boolean canInsert = true;
							ArrayList<Fact> al = null;
							al = idb.get(newfact.predicate);
							if (al != null)
							{
								for (int i = 0; i < al.size(); i++)
								{
									Fact currentFact = al.get(i);
									boolean allequal = true;
									for (int j = 0; j < currentFact.constant.length; j++)
									{
										if (!currentFact.constant[j].name.equals(newfact.constant[j].name))
										{
											allequal = false;
										}
									}
									if (allequal == true)
									{
										canInsert = false;
									}
								}
							}
							if (canInsert == true)
							{
								Print.printFact(newfact);
								ArrayList<Fact> nal = null;
								nal = newidb.get(newfact.predicate);
								if (nal == null)
								{
									nal = new ArrayList<Fact>();
								}
								nal.add(newfact);
								newidb.put(newfact.predicate, nal);
							}
						}
					}
				}
			} else// edb weici
			{
				ArrayList<Fact> localEdb = null;
				localEdb = edb.get(currentSubgoal.predicate);
				if (localEdb != null)
				{
					for (int e = 0; e < localEdb.size(); e++)
					{
						traceOn("matching��" + e + localEdb.get(e).predicate + "\n");
						boolean canMatch = true;
						for (int v = 0; v < currentSubgoal.varia.length; v++)
						{
							if (matched[v] == true && !localEdb.get(e).constant[v].name.equals(instance[v]))
							{
								traceOn("at " + v + " disagreement matching" + "\n");
								canMatch = false;
								break;
							}
						}
						if (canMatch == true)
						{
							for (int v = 0; v < currentSubgoal.varia.length; v++)
							{
								if (matched[v] == false)
								{
									traceOn("add to substitution��" + currentSubgoal.varia[v] + "--"
											+ localEdb.get(e).constant[v].name);
									substitution.put(currentSubgoal.varia[v].name, localEdb.get(e).constant[v].name);
								}
							}
							if (depth < matchRule.body.size() - 1)
								naivematch(depth + 1, substitution, matchRule);
							else
							{
								Term[] consta = new Term[matchRule.head.varia.length];
								for (int i = 0; i < matchRule.head.varia.length; i++)
								{
									if (matchRule.head.varia[i].isVariable)
										consta[i] = new Term(substitution.get(matchRule.head.varia[i].name), false);
									else
										consta[i] = matchRule.head.varia[i];
								}
								Fact newfact = new Fact(-1, matchRule.head.predicate, consta);

								boolean canInsert = true;
								ArrayList<Fact> al = null;
								al = idb.get(newfact.predicate);
								if (al != null)
								{
									for (int i = 0; i < al.size(); i++)
									{
										Fact currentFact = al.get(i);
										boolean allequal = true;
										for (int j = 0; j < currentFact.constant.length; j++)
										{
											if (!currentFact.constant[j].name.equals(newfact.constant[j].name))
											{
												allequal = false;
											}
										}
										if (allequal == true)
										{
											canInsert = false;
										}
									}
								}
								if (canInsert == true)
								{
									Print.printFact(newfact);
									ArrayList<Fact> nal = null;
									nal = newidb.get(newfact.predicate);
									if (nal == null)
									{
										nal = new ArrayList<Fact>();
									}
									nal.add(newfact);
									newidb.put(newfact.predicate, nal);
								}

							}
							for (int v = 0; v < currentSubgoal.varia.length; v++)
							{
								if (matched[v] == false)
								{
									traceOn("delete from substitution��" + currentSubgoal.varia[v] + "--"
											+ localEdb.get(e).constant[v].name + "\n");
									substitution.remove(currentSubgoal.varia[v].name);
								}
							}
						}

					}
				}
			}

		}

	}

	public static int stringCompare(String str1, String str2)
	{
		int ans = 2;
		boolean isNumber1 = false;
		boolean isCharacter1 = false;
		boolean otherSymbol1 = false;
		boolean isNumber2 = false;
		boolean isCharacter2 = false;
		boolean otherSymbol2 = false;

		for (int i = 0; i < str1.length(); i++)
		{
			if (str1.charAt(i) >= 48 && str1.charAt(i) <= 57)
			{
				isNumber1 = true;
			}
			if ((str1.charAt(i) >= 65 && str1.charAt(i) <= 90) || (str1.charAt(i) >= 97 && str1.charAt(i) <= 122))
			{
				isCharacter1 = true;
			}
			if (!(str1.charAt(i) >= 48 && str1.charAt(i) <= 57) && !((str1.charAt(i) >= 65 && str1.charAt(i) <= 90)
					|| (str1.charAt(i) >= 97 && str1.charAt(i) <= 122)))
			{
				otherSymbol1 = true;
			}
		}
		for (int i = 0; i < str2.length(); i++)
		{
			if (str2.charAt(i) >= 48 && str2.charAt(i) <= 57)
			{
				isNumber2 = true;
			}
			if ((str2.charAt(i) >= 65 && str2.charAt(i) <= 90) || (str2.charAt(i) >= 97 && str2.charAt(i) <= 122))
			{
				isCharacter2 = true;
			}
			if (!(str2.charAt(i) >= 48 && str2.charAt(i) <= 57) && !((str2.charAt(i) >= 65 && str2.charAt(i) <= 90)
					|| (str2.charAt(i) >= 97 && str2.charAt(i) <= 122)))
			{
				otherSymbol2 = true;
			}
		}

		if (isNumber1 && isNumber2 && !isCharacter1 && !isCharacter2 && !otherSymbol1 && !otherSymbol2)
		{
			int i1 = Integer.valueOf(str1);
			int i2 = Integer.valueOf(str2);
			if (i1 > i2)
				ans = 1;
			if (i1 < i2)
				ans = -1;
			if (i1 == i2)
				ans = 0;
		}
		if (!isNumber1 && !isNumber2 && isCharacter1 && isCharacter2 && !otherSymbol1 && !otherSymbol2)
		{
			if (str1.compareToIgnoreCase(str2) < 0)
				ans = -1;
			else
				ans = 1;
		}
		return ans;
	}

	public static void traceOn(String str)
	{
		if (Codalog.trace)
		{
			System.out.print(str);
		}
	}

	public static void printOn(String str)
	{
		if (Codalog.fileprint)
		{
			Output.writeOutput(str);
		}
	}
}